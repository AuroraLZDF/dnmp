Simple QrCode
=============

##Change Log

#### 1.3.3
* Allow absolute paths to be used with the `merge` method.

#### 1.3.2
* Changed `bindShared` to `singleton` to support Laravel 5.2  -Thanks [lhdev!](https://github.com/lhdev)

#### 1.3.1
* Fixed a bug where `merge` did not work as expected when used with `size.`

#### 1.3.0
* Added `merge` method.
* Fixed a typo in the readme.

#### 1.2.0
* Added full support for Laravel 5
* Added the following helpers.
  * E-Mail
  * Geo
  * Phone Number
  * SMS
  * WiFi

#### 1.1.1
* Update dependencies.
* Corrected some composer file issues.
* Added some missing Laravel information to the QrCode Service Provider.

####1.1.0
* Added the ability to change the character encoding.
